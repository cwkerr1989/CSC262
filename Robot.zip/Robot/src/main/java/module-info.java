module com.csc262.robot {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.csc262.robot to javafx.fxml;
    exports com.csc262.robot;
}
